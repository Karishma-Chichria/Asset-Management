<p>&nbsp;</p>
<p><small>&copy; 2005 MyOnlineShop&nbsp;</small></p>
</body>
</html>